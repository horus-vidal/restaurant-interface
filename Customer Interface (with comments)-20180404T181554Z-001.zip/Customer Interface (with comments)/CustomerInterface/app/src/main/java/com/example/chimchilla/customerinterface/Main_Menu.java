// main (reset) activity -> customer main menu -> food menu
package com.example.chimchilla.customerinterface;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class Main_Menu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main__menu);
        Button EntreesBtn = (Button) findViewById(R.id.EntreesBtn);
        EntreesBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent startIntent = new Intent(getApplicationContext(), EntreeListActivity.class);
                startActivity(startIntent);
            }
        });
    }
}
