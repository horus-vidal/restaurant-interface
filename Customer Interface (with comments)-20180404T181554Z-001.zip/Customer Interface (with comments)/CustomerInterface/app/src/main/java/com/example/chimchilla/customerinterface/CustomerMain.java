// main -> customer menu
package com.example.chimchilla.customerinterface;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class CustomerMain extends AppCompatActivity {

    @Override
//~~~~~~~~~~~~~~~~~~~~~~~~~~~Button for Food Menu ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_main);


        Button MainMenuBtn = (Button) findViewById(R.id.MainMenuBtn);
        MainMenuBtn.setOnClickListener(new View.OnClickListener() {
                                          @Override
                                          public void onClick(View view) {
                                              Intent startIntent = new Intent(getApplicationContext(), Main_Menu.class);
                                              startActivity(startIntent);

        }
    });
    }
//~~~~~~~~~~~~~~~~~~~~~~~~~~~Button for Games ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
//~~~~~~~~~~~~~~~~~~~~~~~~~~~Button for Music ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
//~~~~~~~~~~~~~~~~~~~~~~~~~~~Button for Daily Specials ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

}